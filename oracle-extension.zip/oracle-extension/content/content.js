// ORACLE Content Script
// Injected into Kalshi pages to provide real-time analysis

(function() {
  'use strict';

  // State
  let state = {
    settings: null,
    currentMarket: null,
    modelProbability: 0.5,
    isMinimized: false,
    panelElement: null,
    observer: null,
    lastUrl: null
  };

  // Initialize
  async function init() {
    console.log('[ORACLE] Initializing...');
    
    // Load settings
    state.settings = await ORACLE_STORAGE.getSettings();
    
    // Create panel
    createPanel();
    
    // Start observing for market data
    observeMarketChanges();
    
    // Check for market data immediately
    detectMarket();
    
    // Listen for URL changes (SPA navigation)
    setInterval(checkUrlChange, 500);
    
    console.log('[ORACLE] Initialized successfully');
  }

  // Check for URL changes
  function checkUrlChange() {
    if (window.location.href !== state.lastUrl) {
      state.lastUrl = window.location.href;
      setTimeout(detectMarket, 500);
    }
  }

  // Create the ORACLE panel
  function createPanel() {
    // Remove existing panel if any
    const existing = document.getElementById('oracle-panel');
    if (existing) existing.remove();

    const panel = document.createElement('div');
    panel.id = 'oracle-panel';
    panel.innerHTML = getPanelHTML();
    document.body.appendChild(panel);
    
    state.panelElement = panel;
    
    // Attach event listeners
    attachEventListeners();
  }

  // Get panel HTML
  function getPanelHTML() {
    return `
      <div class="oracle-header">
        <div class="oracle-logo">
          <div class="oracle-logo-icon"></div>
          <span>ORACLE</span>
        </div>
        <div class="oracle-controls">
          <button class="oracle-btn" id="oracle-refresh" title="Refresh">↻</button>
          <button class="oracle-btn" id="oracle-minimize" title="Minimize">−</button>
        </div>
      </div>
      <div class="oracle-body">
        <div class="oracle-loading">
          <div class="oracle-spinner"></div>
        </div>
      </div>
    `;
  }

  // Get analysis content HTML
  function getAnalysisHTML(market, recommendation) {
    const display = ORACLE_EDGE.formatForDisplay(recommendation);
    const edgeWidth = Math.min(Math.abs(recommendation.edge.edgePercent) * 5, 100);
    
    return `
      <div class="oracle-section">
        <div class="oracle-section-title">Market</div>
        <div class="oracle-market-title">${market.title}</div>
        <div class="oracle-prices">
          <div class="oracle-price-item">
            <span class="oracle-price-label">YES</span>
            <span class="oracle-price-value yes">$${market.yesPrice.toFixed(2)}</span>
          </div>
          <div class="oracle-price-item">
            <span class="oracle-price-label">NO</span>
            <span class="oracle-price-value no">$${market.noPrice.toFixed(2)}</span>
          </div>
        </div>
      </div>
      
      <div class="oracle-divider"></div>
      
      <div class="oracle-section">
        <div class="oracle-section-title">Your Probability</div>
        <div class="oracle-slider-container">
          <div class="oracle-slider-header">
            <span class="oracle-prob-value" id="oracle-prob-display">${(state.modelProbability * 100).toFixed(0)}%</span>
            <span class="oracle-confidence ${display.confidenceClass || 'none'}">${display.confidence || 'SET PROBABILITY'}</span>
          </div>
          <input type="range" 
                 class="oracle-slider" 
                 id="oracle-prob-slider" 
                 min="1" 
                 max="99" 
                 value="${state.modelProbability * 100}">
        </div>
      </div>
      
      <div class="oracle-divider"></div>
      
      <div class="oracle-section">
        <div class="oracle-section-title">Analysis</div>
        <div class="oracle-analysis-grid">
          <div class="oracle-analysis-item">
            <div class="oracle-analysis-label">Edge</div>
            <div class="oracle-analysis-value ${recommendation.edge.edge > 0 ? 'positive' : recommendation.edge.edge < 0 ? 'negative' : ''}">${display.edgeText || '0.0%'}</div>
            <div class="oracle-edge-bar">
              <div class="oracle-edge-fill ${recommendation.confidence === 'HIGH' ? 'high' : ''}" style="width: ${edgeWidth}%"></div>
            </div>
          </div>
          <div class="oracle-analysis-item">
            <div class="oracle-analysis-label">Kelly Size</div>
            <div class="oracle-analysis-value purple">${display.cost || '$0.00'}</div>
            <div class="oracle-analysis-label" style="margin-top: 4px">${display.bankrollPercent || '0%'} of bankroll</div>
          </div>
          <div class="oracle-analysis-item">
            <div class="oracle-analysis-label">Expected Value</div>
            <div class="oracle-analysis-value ${recommendation.expectedValue?.expectedValue > 0 ? 'positive' : ''}">${display.expectedValue || '$0.00'}</div>
          </div>
          <div class="oracle-analysis-item">
            <div class="oracle-analysis-label">If Win</div>
            <div class="oracle-analysis-value positive">${display.potentialProfit || '$0.00'}</div>
          </div>
        </div>
      </div>
      
      <div class="oracle-divider"></div>
      
      <div class="oracle-section">
        <button class="oracle-recommendation ${getRecommendationClass(recommendation)}" id="oracle-rec-btn">
          <span class="oracle-rec-icon">${getRecommendationIcon(recommendation)}</span>
          <span>${display.actionText}</span>
          ${display.price ? `<span>@ ${display.price}</span>` : ''}
        </button>
        ${recommendation.action !== 'PASS' ? 
          `<div class="oracle-subtext">Recommended: ${display.contracts} contracts</div>` :
          `<div class="oracle-subtext">${display.reason || 'Adjust probability to analyze'}</div>`
        }
      </div>
      
      <div class="oracle-quick-stats">
        <div class="oracle-quick-stat">
          <div class="oracle-quick-stat-value">$${state.settings.bankroll.toLocaleString()}</div>
          <div class="oracle-quick-stat-label">Bankroll</div>
        </div>
        <div class="oracle-quick-stat">
          <div class="oracle-quick-stat-value">${(state.settings.kellyFraction * 100).toFixed(0)}%</div>
          <div class="oracle-quick-stat-label">Kelly</div>
        </div>
        <div class="oracle-quick-stat">
          <div class="oracle-quick-stat-value">${(state.settings.minEdgeThreshold * 100).toFixed(0)}%</div>
          <div class="oracle-quick-stat-label">Min Edge</div>
        </div>
      </div>
    `;
  }

  // Get no market HTML
  function getNoMarketHTML() {
    return `
      <div class="oracle-no-market">
        <div class="oracle-no-market-icon">📊</div>
        <div>Navigate to a Kalshi market to analyze</div>
      </div>
    `;
  }

  // Get recommendation button class
  function getRecommendationClass(rec) {
    if (rec.action === 'PASS') return 'pass';
    if (rec.side === 'YES') return 'buy-yes';
    if (rec.side === 'NO') return 'buy-no';
    return 'pass';
  }

  // Get recommendation icon
  function getRecommendationIcon(rec) {
    if (rec.action === 'PASS') return '⏸';
    if (rec.side === 'YES') return '📈';
    if (rec.side === 'NO') return '📉';
    return '⏸';
  }

  // Attach event listeners
  function attachEventListeners() {
    // Minimize button
    document.getElementById('oracle-minimize')?.addEventListener('click', toggleMinimize);
    
    // Refresh button
    document.getElementById('oracle-refresh')?.addEventListener('click', () => {
      detectMarket();
    });
  }

  // Attach slider listener (called after analysis renders)
  function attachSliderListener() {
    const slider = document.getElementById('oracle-prob-slider');
    const display = document.getElementById('oracle-prob-display');
    
    if (slider && display) {
      slider.addEventListener('input', (e) => {
        state.modelProbability = e.target.value / 100;
        display.textContent = `${e.target.value}%`;
        updateAnalysis();
      });
    }
  }

  // Toggle minimize
  function toggleMinimize() {
    state.isMinimized = !state.isMinimized;
    state.panelElement?.classList.toggle('minimized', state.isMinimized);
    const btn = document.getElementById('oracle-minimize');
    if (btn) btn.textContent = state.isMinimized ? '+' : '−';
  }

  // Detect market data from page
  function detectMarket() {
    console.log('[ORACLE] Detecting market...');
    
    // Try multiple selectors for Kalshi's UI
    const market = extractMarketData();
    
    if (market) {
      state.currentMarket = market;
      updateAnalysis();
    } else {
      showNoMarket();
    }
  }

  // Extract market data from page DOM
  function extractMarketData() {
    try {
      // Get market title - try multiple selectors
      let title = null;
      const titleSelectors = [
        'h1[class*="title"]',
        'h1[class*="Title"]',
        '[class*="market-title"]',
        '[class*="MarketTitle"]',
        '[class*="eventTitle"]',
        '[data-testid="market-title"]',
        'h1',
        'h2'
      ];
      
      for (const selector of titleSelectors) {
        const el = document.querySelector(selector);
        if (el && el.textContent.trim().length > 5) {
          title = el.textContent.trim();
          break;
        }
      }

      // Get prices - look for price elements
      let yesPrice = null;
      let noPrice = null;
      
      // Try to find price from URL or page content
      const priceSelectors = [
        '[class*="price"]',
        '[class*="Price"]',
        '[class*="odds"]',
        '[class*="Odds"]',
        '[class*="yes"]',
        '[class*="Yes"]',
        '[class*="no"]',
        '[class*="No"]'
      ];

      // Look for text content with price patterns
      const allText = document.body.innerText;
      
      // Pattern: "Yes $0.XX" or "Yes 42¢" or "YES: 42%"
      const yesMatch = allText.match(/yes[:\s]*\$?(0?\.\d{2}|\d{1,2}[¢%]?)/i);
      const noMatch = allText.match(/no[:\s]*\$?(0?\.\d{2}|\d{1,2}[¢%]?)/i);
      
      if (yesMatch) {
        yesPrice = ORACLE_EDGE.parsePrice(yesMatch[1]);
      }
      if (noMatch) {
        noPrice = ORACLE_EDGE.parsePrice(noMatch[1]);
      }

      // Try specific Kalshi selectors
      const yesBtnSelectors = [
        '[class*="yes"] [class*="price"]',
        '[class*="Yes"] [class*="Price"]',
        'button[class*="yes"]',
        '[data-side="yes"]',
        '[class*="buy-yes"]'
      ];
      
      const noBtnSelectors = [
        '[class*="no"] [class*="price"]',
        '[class*="No"] [class*="Price"]',
        'button[class*="no"]',
        '[data-side="no"]',
        '[class*="buy-no"]'
      ];

      for (const selector of yesBtnSelectors) {
        const el = document.querySelector(selector);
        if (el) {
          const priceText = el.textContent.match(/\$?(0?\.\d{2}|\d{1,2})[¢%]?/);
          if (priceText) {
            yesPrice = ORACLE_EDGE.parsePrice(priceText[0]);
            break;
          }
        }
      }

      for (const selector of noBtnSelectors) {
        const el = document.querySelector(selector);
        if (el) {
          const priceText = el.textContent.match(/\$?(0?\.\d{2}|\d{1,2})[¢%]?/);
          if (priceText) {
            noPrice = ORACLE_EDGE.parsePrice(priceText[0]);
            break;
          }
        }
      }

      // If we only have one price, calculate the other
      if (yesPrice && !noPrice) {
        noPrice = 1 - yesPrice;
      } else if (noPrice && !yesPrice) {
        yesPrice = 1 - noPrice;
      }

      // Fallback: look for any decimal numbers that could be prices
      if (!yesPrice || !noPrice) {
        const pricePattern = /\b(0\.\d{2})\b/g;
        const matches = [...allText.matchAll(pricePattern)].map(m => parseFloat(m[1]));
        const validPrices = matches.filter(p => p > 0.01 && p < 0.99);
        
        if (validPrices.length >= 2) {
          // Assume first two are yes/no
          yesPrice = yesPrice || validPrices[0];
          noPrice = noPrice || validPrices[1];
        } else if (validPrices.length === 1) {
          yesPrice = yesPrice || validPrices[0];
          noPrice = noPrice || (1 - validPrices[0]);
        }
      }

      // Final fallback: default prices for testing
      if (!yesPrice) yesPrice = 0.50;
      if (!noPrice) noPrice = 1 - yesPrice;

      // Get market ID from URL
      const urlParts = window.location.pathname.split('/');
      const marketId = urlParts[urlParts.length - 1] || urlParts[urlParts.length - 2];

      // Only return if we have a title (indicates we're on a market page)
      if (!title || title.length < 5) {
        // Check if URL suggests we're on a market page
        if (!window.location.pathname.includes('/markets/') && 
            !window.location.pathname.includes('/event/')) {
          return null;
        }
        title = `Market: ${marketId}`;
      }

      return {
        id: marketId,
        title: title.substring(0, 100),
        yesPrice: yesPrice,
        noPrice: noPrice,
        url: window.location.href
      };
    } catch (error) {
      console.error('[ORACLE] Error extracting market data:', error);
      return null;
    }
  }

  // Update analysis display
  function updateAnalysis() {
    if (!state.currentMarket) {
      showNoMarket();
      return;
    }

    const recommendation = ORACLE_EDGE.generateRecommendation(
      state.modelProbability,
      state.currentMarket.yesPrice,
      state.currentMarket.noPrice,
      state.settings
    );

    const body = state.panelElement?.querySelector('.oracle-body');
    if (body) {
      body.innerHTML = getAnalysisHTML(state.currentMarket, recommendation);
      attachSliderListener();
    }
  }

  // Show no market state
  function showNoMarket() {
    const body = state.panelElement?.querySelector('.oracle-body');
    if (body) {
      body.innerHTML = getNoMarketHTML();
    }
  }

  // Observe for DOM changes (SPA updates)
  function observeMarketChanges() {
    if (state.observer) {
      state.observer.disconnect();
    }

    state.observer = new MutationObserver((mutations) => {
      // Debounce updates
      clearTimeout(state.updateTimeout);
      state.updateTimeout = setTimeout(() => {
        detectMarket();
      }, 1000);
    });

    state.observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }

  // Listen for messages from popup/background
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'UPDATE_SETTINGS') {
      state.settings = message.settings;
      updateAnalysis();
      sendResponse({ success: true });
    }
    
    if (message.type === 'GET_MARKET_DATA') {
      sendResponse({ 
        market: state.currentMarket,
        probability: state.modelProbability
      });
    }

    if (message.type === 'SET_PROBABILITY') {
      state.modelProbability = message.probability;
      updateAnalysis();
      sendResponse({ success: true });
    }

    return true;
  });

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
